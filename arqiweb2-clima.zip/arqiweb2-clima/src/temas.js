// Tema do projeto: Mudanças climáticas.
// p1 = escolha única, p2 = escala de 1 a 5, p3 = texto livre (opcional).
export const TEMA = {
  id: 'clima',
  nome: 'Mudanças climáticas',
  p1: {
    texto: 'Você sente que o calor em Araraquara mudou nos últimos anos?',
    opcoes: ['Piorou muito', 'Piorou um pouco', 'Não mudou', 'Não sei dizer'],
  },
  p2: 'De 1 a 5, quanto as mudanças climáticas afetam a sua rotina hoje?',
  p3: 'O que o campus poderia fazer para diminuir o impacto do calor no dia a dia?',
};
